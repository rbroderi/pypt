﻿import importlib


def test_package_importable() -> None:
    module = importlib.import_module("example")
    assert module is not None
